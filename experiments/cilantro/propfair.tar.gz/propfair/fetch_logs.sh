#!/usr/bin/env bash
set -e

CONFIG_PATH=$1

# If CONFIG_PATH is not provided, use the default kubeconfig
if [ -z "$CONFIG_PATH" ]; then
    CONFIG_PATH=~/.kube/config
fi

kubectl logs $(kubectl get pods --kubeconfig ${CONFIG_PATH} | awk '/cilantroscheduler/ {print $1;exit}') --kubeconfig ${CONFIG_PATH} > cilantroscheduler.log
kubectl -c 'hr-client' logs $(kubectl get pods --kubeconfig ${CONFIG_PATH} | awk '/hr-client/ {print $1;exit}') --kubeconfig ${CONFIG_PATH} > hr-client.log
kubectl -c 'cilantro-hr-client' logs $(kubectl get pods --kubeconfig ${CONFIG_PATH} | awk '/hr-client/ {print $1;exit}') --kubeconfig ${CONFIG_PATH} > cilantro-hr-client.log
